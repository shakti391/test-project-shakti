document.getElementById("homepage").addEventListener("click", function() {
    window.location.href = "index.html"; // Change to your homepage URL
});
document.getElementById("image-home").addEventListener("click", function() {
    window.location.href = "index.html"; // Change to your homepage URL
});
